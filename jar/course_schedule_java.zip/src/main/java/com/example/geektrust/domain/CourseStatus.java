package com.example.geektrust.domain;

public enum CourseStatus {
    NOT_STARTED,
    CONFIRMED,
    COURSE_CANCELED;
}
