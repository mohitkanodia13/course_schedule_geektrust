package com.example.geektrust.domain;

public enum RegistrationStatus {
    ACCEPTED,
    CANCEL_ACCEPTED,
    CANCEL_REJECTED,
    CANCELLED;
}