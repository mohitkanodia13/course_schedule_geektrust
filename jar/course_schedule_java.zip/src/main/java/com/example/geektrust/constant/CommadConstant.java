package com.example.geektrust.constant;

public class CommadConstant {
    public static final String ADD_COURSE = "ADD-COURSE-OFFERING";
    public static final String REGITER = "REGISTER";
    public static final String ALLOT = "ALLOT";
    public static final String CANCEL = "CANCEL";
}
